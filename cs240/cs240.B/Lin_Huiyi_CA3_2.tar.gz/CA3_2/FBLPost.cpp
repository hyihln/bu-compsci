

#include <iostream>
#include <stdlib.h>
#include "FBLPost.h"

using namespace std;

FBLPost::FBLPost(string t){

	next = NULL;
	message = t;

}
