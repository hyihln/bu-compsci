

#include <iostream>
#include <stdlib.h>
#include "FBLCommentLL.h"

using namespace std;

FBLCommentLL::FBLCommentLL(){
	firstComment = NULL;
	lastComment = NULL;
}
