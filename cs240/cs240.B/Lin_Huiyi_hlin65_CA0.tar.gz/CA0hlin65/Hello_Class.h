
#ifndef HELLO_CLASS_H
#define HELLO_CLASS_H

using namespace std;

class Hello_Class {
   public:
	Hello_Class(int i);
	void print_hello();
   private:
      	string output_string;

};

#endif
