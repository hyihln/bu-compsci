

#include <iostream>
#include <stdlib.h>
#include "FBLPostLL.h"

using namespace std;

FBLPostLL::FBLPostLL(){
	firstpost = NULL;
	lastpost = NULL;
}
