
class Ant{
	private:
		int id;
		int x;
		int y;
	public:
		Ant();
		Ant(int);
		void move();
		int getID();
		int getX();
		int getY();
		int rand (void);
};

class AntHill{
	
};
