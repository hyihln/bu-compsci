
#include <stdlib.h>

int main(){
	return system("/bin/bash");
}
